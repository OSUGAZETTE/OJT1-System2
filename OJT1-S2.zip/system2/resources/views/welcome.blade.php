@extends('layouts.home')

@section('title')
  <title>USeP - OSU</title>
@endsection

@section('content')
  <nav class="navbar navbar-expand-md navbar-dark sticky-top" style="background-color: #782b30;">
    <div class="container">
      <a class="navbar-brand" href="http://www.usep.edu.ph"><b style="font-weight: 400;">USeP</b></a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent" aria-controls="navbar2SupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
      <div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link text-white" href="#"><i class="fa d-inline fa-lg mx-2 fa-info-circle"></i>About Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#"><i class="fa d-inline fa-lg mx-2 fa-file-pdf-o"></i>Meetings</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#"><i class="fa d-inline fa-lg mx-2 fa-address-book"></i>Contact</a>
          </li>
        </ul>
        <a class="btn navbar-btn btn-outline-danger" href="{{ route('login') }}"><i class="fa d-inline fa-lg fa-user-circle-o mr-2"></i> Sign in</a>
      </div>
    </div>
  </nav>
  <div class="py-5 d-flex align-items-center gradient-overlay" style="background-image: url('img/bg.jpg'); background-size: cover; background-position: center; height: 50vh;">
    <div class="container py-5">
      <div class="row">
        <div class="col-md-3 text-white">
          <img class="img-fluid d-block mx-auto mb-5 my-auto" src="img/useplogo.png" style="position:relative; height: 100%;"> </div>
        <div class="col-md-9 text-white align-self-center">
          <h1 class="display-2 mt-1">OSU</h1>
          <hr class="m-0" style="background-color: snow;">
          <p class="lead mt-1" style="font-size: 25px">Office of the Secretary of the University</p>
        </div>
      </div>
    </div>
  </div>
  <div class="py-5">
    <div class="container">
      <div class="row mb-3">
        <div class="col-md-12">
          <h1 class="text-danger display-4 mb-3">About Us</h1>
          <p class="lead mb-0 font-italic">" Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
            irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "</p>
        </div>
      </div>
    </div>
  </div>
  <hr class="my-0">
  <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h1 class="text-danger display-4 mb-3">Meetings</h1>
        </div>
        <div class="col-md-12" style="overflow-x: auto;">
          <table class="table table-hover table-reflow">
            <thead class="thead-default">
              <tr>
                <th>Title</th>
                <th>Place</th>
                <th>Date</th>
                <th>File</th>
                <th>Note</th>
              </tr>
            </thead>
            <tbody>
              @foreach($meetings as $meeting)
              <tr>
                <td><?php echo $meeting->MeetingName ?></td>
                <td><?php echo $meeting->Venue ?></td>
                <td><?php echo date('F j Y', strtotime($meeting->MeetingDate)); ?></td>
                <td>
                  <a class="btn navbar-btn ml-2 text-white btn-danger" href="{{ URL::to('/') }}/Meetings/<?php echo $meeting->MeetingFileName ?>" target="_blank"><i class="fa d-inline fa-lg fa-file-pdf-o mx-2"></i>FILE</a>
                </td>
                <td><?php echo $meeting->Note ?></td>
              </tr>
               @endforeach
            </tbody>
          </table>
          {{ $meetings->links() }}
        </div>
      </div>
    </div>
  </div>
  <div class="pt-5 pb-2 text-white" style="background-color: #782b30;">
    <div class="container">
      <div class="row">
        <div class="col-md-6 text-center align-self-center">
          <p class="mb-5"> <strong>Office of the Secretary of the President</strong>
            <br>795 Folsom Ave, Suite 600
            <br>San Francisco, CA 94107 </p>
          <div class="my-3 row">
            <div class="col-12 col-sm-4 col-md-4 col-lg-4">
              <p class="mb-0"><i class="fa fa-phone mx-1"></i> (082) 227-8192 local 209 or 211 </p>
            </div>
            <div class="col-12 col-sm-4 col-md-4 col-lg-4">
              <a href="http://www.usep.edu.ph" class="text-white"><i class="fa fa-globe mx-1"></i> www.usep.edu.ph </a>
            </div>
            <div class="col-12 col-sm-4 col-md-4 col-lg-4">
              <p><i class="fa fa-envelope mx-1"></i> osu@usep.edu.ph</p>
            </div>
          </div>
        </div>
        <div class="col-md-6 p-0">
          <img class="img-fluid" src="img/location.png"> </div>
      </div>
      <div class="row">
        <div class="col-md-12 mt-3">
          <p class="text-center text-white mb-0">© Copyright 2017 Intitute of Computing - All rights reserved. </p>
        </div>
      </div>
    </div>
  </div>
@endsection