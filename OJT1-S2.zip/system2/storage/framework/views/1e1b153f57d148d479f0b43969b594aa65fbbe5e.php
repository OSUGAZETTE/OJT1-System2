<?php $__env->startSection('title'); ?>
  <title>OSU | DASHBOARD</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('a1'); ?>
  class="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-inner">
  <section class="forms py-0">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card my-3">
            <div class="card-close CC">
              <form method="GET" action="<?php echo e(url('/Home')); ?>" role="search" class="navbar-form navbar-left mb-0">
                <div class="input-group custom-search-form">
                    <input type="text" class="form-control " name="search" placeholder="Search...">
                      <span class="input-group-btn">
                        <button class="mi btn text-white btn-danger" type="submit">
                            Submit
                        </button>
                      </span>
                </div>
              </form>
            </div>
            <div class="card-header d-flex align-items-center">
              <h3 class="h4">Meetings</h3>
            </div>
            <table class="table mb-0">
              <thead>
                <tr>
                  <!--<th class="text-center">#</th>-->
                  <th class="text-center" style="vertical-align: middle; width:17%">Title</th>
                  <th class="text-center" style="vertical-align: middle; width:17%">Place</th>
                  <th class="text-center" style="vertical-align: middle; width:17%">Date</th>
                  <th class="text-center" style="vertical-align: middle; width:17%">File</th>
                  <th class="text-center" style="vertical-align: middle; width:17%">Note</th>
                </tr>
              </thead>
            </table>
            <div class="card-body p-2" style="height: calc(100vh - 265px);overflow: auto;">
              <table class="table table-striped">
                <tbody>
                  <?php $__currentLoopData = $meetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <!--<td class="p-2" style="vertical-align: middle;width: 5%;">
                      <p class="mb-0 py-auto text-center "><?php echo e($loop->iteration); ?></p>
                    </td>-->
                    <td class="p-2" style="vertical-align: middle; width:17%">
                      <p class="mb-0 py-auto text-center "><?php echo $meeting->MeetingName ?></p>
                    </td>
                    <td class="p-2" style="vertical-align: middle; width:17%">
                      <p class="mb-0 py-auto text-center "><?php echo $meeting->Venue ?></p>
                    </td>
                    <td class="p-2" style="vertical-align: middle; width:17%">
                      <p class="mb-0 py-auto text-center "><?php echo date('F j Y', strtotime($meeting->MeetingDate)); ?></p>
                    </td>
                    <td class="p-2" style="vertical-align: middle; width:17%">
                       <a class="btn navbar-btn text-center w-100 text-white btn-danger" href="<?php echo e(URL::to('/')); ?>/Meetings/<?php echo $meeting->MeetingFileName ?>" target="_blank" style="cursor: pointer;"><i class="fa d-inline fa-lg fa-file-pdf-o mx-2"></i>FILE</a>
                    </td>
                    <td class="p-2" style="vertical-align: middle; width:17%">
                      <p class="mb-0 py-auto text-center tp"><?php echo $meeting->Note ?></p>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>

            </div>
            <?php echo e($meetings->links()); ?>

            <!--<?php echo $__env->make('layouts.paginator', ['paginator' => $meetings], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>-->
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>